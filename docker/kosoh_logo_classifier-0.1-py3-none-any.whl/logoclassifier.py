import numpy as np
import matplotlib.pyplot as plt
import glob
import pandas as pd
import cv2 as cv
#import gif2numpy
from scipy import ndimage
import pkg_resources
import imageio


class LogoClassifierECG:
    """
    Search for images in path and determine if they match a reference image
    """
    def __init__(self):

        # the reference image is rea
        resource_package = __name__
        resource_path = '/'.join(('trustmark/ecguetesiegel', 'train_ecg.png')) 
        ecg_file = pkg_resources.resource_filename(resource_package, resource_path)
        self.reference_hist = self.calc_hist(ecg_file)
        # threshold for classification
        self.threshold = 0.52
        # histogram similarity metric accoring to opencv compareHist
        self.selector_metric = 3
        # usually values smaller than treshold are True predictions, but some metrics require the opposite
        self.gt_treshold = False
        # file ending for images that will be evaluated
        self.image_endings = [".png", ".jpg", ".jpeg",".gif"]
        # show output in debug mode
        self.debug = False
        # print figures for compare multiple
        self.show_figs = False
    def search_images_path(self, path):
        """ Searches path for images using glob. filters  using expressions in self.image_endings
        Parameters:
            path(str): expression for glog.glob

        Returns:
            all_iamge_paths(list): list of paths matching glob expression and file endings
        """
        all_iamge_paths = glob.glob(path)
        all_iamge_paths = [x for x in all_iamge_paths if any([x.endswith(ending) for ending in self.image_endings])]
        if self.debug:
            print("%s images found in %s!"%(len(all_iamge_paths),path))
        if len(all_iamge_paths)==0:
            if self.debug:
                print("No images found in path expression!")
            #raise FileNotFoundError("No images found in path expression!")
        return all_iamge_paths

    def image_read(self, path):
        if path.endswith(".gif"):
            src_base = imageio.imread(path)
        else:
            src_base = cv.imread(path)

            if src_base is None:
                raise FileNotFoundError("could not read at %s" % path)
            else:
                src_base = src_base[..., ::-1]
        return src_base

    def calc_hist(self, path):
        """read images and calculate histogram
        Parameters:
            path (str): path to image to classify
        Returns:
            hist_base(numpy.ndarray):normalized histogram of input image
        """

        src_base = self.image_read(path)

        hsv_base = cv.cvtColor(src_base, cv.COLOR_BGR2HSV)
        h_bins = 50
        s_bins = 60
        histsize = [h_bins, s_bins]
        # hue varies from 0 to 179, saturation from 0 to 255
        h_ranges = [0, 180]
        s_ranges = [0, 256]
        ranges = h_ranges + s_ranges  # concat lists
        # Use the 0-th and 1-st channels
        channels = [0, 1]
        hist_base = cv.calcHist([hsv_base], channels, None, histsize, ranges, accumulate=False)
        cv.normalize(hist_base, hist_base, alpha=0, beta=1, norm_type=cv.NORM_MINMAX)
        return hist_base

    def create_hist_test(self, file_list):
        """ creates a dictionary with paths of images as key and histograms as values
        """

        hist_dict = {}
        for path in file_list:
            try:
                hist_dict[path] = self.calc_hist(path)
            except Exception as e:
                print(path)
                print(e)
        return hist_dict

    def siminilarity_df_one_vs_all(self, hist_dict, compare_method):
        """ Compates histograms all histogramms in dict to reference histogram
        Parameters:
            hist_dict(dict): dict from create_hist_test
            compare_method(int): range(4), metric to compare histograms
        Returns:
            df(pd.DataFrame): with similarity score and path as index
        """
        outer = {}
        for path, hist in hist_dict.items():

            try:
                score = cv.compareHist(hist, self.reference_hist, compare_method)
            except Exception as e:
                print("Score could not be calculated for %s"%path)
                print(e)
                score = np.nan

            outer[path] = score
        df = pd.DataFrame.from_dict(outer, orient="index", columns=["Score"])
        return df  # [df.index]




    def list_similar_images(self, path):
        """ Returns list of paths of images that match the reference image
        Parameters:
            path(str): glob expression for images that should be evaluates
        Returns:
           list of paths of images that match the reference image
        """
        paths = self.search_images_path(path)
        hist_dict = self.create_hist_test(paths)
        df = self.siminilarity_df_one_vs_all(hist_dict=hist_dict, compare_method=self.selector_metric)
        if self.gt_treshold:
            return list(df.loc[df["Score"] > self.threshold, "Score"].index)
        else:
            return list(df.loc[df["Score"] < self.threshold, "Score"].index)

    def plot_cluster(self, path):
        """ plots all matching images in one figure
        Parameters:
            path(str): glob expression for images that should be evaluates
        Returns:
            fig(matplotlib.pyplot.figure): of all matching figures
        """
        list_similar = self.list_similar_images(path)
        dim = int(np.ceil(np.sqrt(len(list_similar))))
        if len(list_similar) > 1:
            if dim > 10:
                fig, axs = plt.subplots(dim, dim, figsize=(20, 10))
            else:
                fig, axs = plt.subplots(dim, dim, figsize=(dim * 3, dim * 3))

            for x, ax in zip(list_similar, [b for a in axs for b in a][0:len(list_similar)]):
                try:
                    img = self.image_read(x)
                except Exception as e:
                    print(e)
                    continue
                ax.imshow(img)
                ax.title.set_text(x.split("/")[-2])
                # ax.axis('off')
                ax.set_xlabel(x.split("/")[1])
        elif len(list_similar) == 1:
                fig = plt.figure()
                plt.imshow(self.image_read(list_similar[0]))

        else:
            #print("No match found!")
            fig = np.nan
        return fig

    def contains_logo(self, path):
        """ Is any image in path similar to the reference image?
        Parameters:
            path(str): glob expression for images that should be evaluates
        Returns:
            bool
        """
        list_similar = self.list_similar_images(path)
        if len(list_similar) > 0:
            return True
        else:
            return False

    def compare_multiple(self, path_test, path_train_folder):
        """ Compares all train images with all test images, any match will result in a positive
        Parameters:
        Returns:

        """


        train_images = self.search_images_path(path_train_folder)
        sols = []
        figs  = []
        for train in train_images:


            self.reference_hist = self.calc_hist(train)
            sol = self.contains_logo(path_test)
            if self.show_figs and sol:
                #print("PRINT FIGURE")
                fig = self.plot_cluster(path_test)
                #print(path_test)
                #print(train)
                #print(fig)
                figs.append(fig)

            sols.append(sol)
        return any(sols), figs


def compare_multiple2(path_test, path_train_folder):
    """ Compares all train images with all test images, any match will result in a positive
    Parameters:
    Returns:

    """
    Classifier = LogoClassifierECG()
    Classifier.threshold = 0.9999
    Classifier.selector_metric = 0
    Classifier.gt_treshold = True


    train_images = Classifier.search_images_path(path_train_folder)

    sols = []
    figs  = []
    for train in train_images:
        Classifier.reference_hist = Classifier.calc_hist(train)
        sol = Classifier.contains_logo(path_test)
        if Classifier.debug and sol:
            print("PRINT FIGURE")
            fig = Classifier.list_similar_images(path_test)
            print(path_test)
            print(train)
            print(fig)
            figs.append(fig)

        sols.append(sol)
    return any(sols), figs


def contains_logo_hybrid(path):
    Classifier = LogoClassifierECG()

    resource_path = '/'.join(('trustmark/ecguetesiegel', 'train_ecg_large.png'))  # Do not use os.path.join()
    resource_package = __name__
    ecg_large_file = pkg_resources.resource_filename(resource_package, resource_path)

    Classifier.threshold = 0.62
    Classifier.reference_hist = Classifier.calc_hist(ecg_large_file)
    model1 = Classifier.contains_logo(path)

    resource_path = '/'.join(('trustmark/ecguetesiegel', 'train_ecg_small.png'))  # Do not use os.path.join()
    ecg_small_file = pkg_resources.resource_filename(resource_package, resource_path)

    Classifier.threshold = 0.7
    Classifier.reference_hist = Classifier.calc_hist(ecg_small_file)
    model2 = Classifier.contains_logo(path)

    if any([model1,model2]):
        return True
    else:
        return False

def list_available_trainingsdata_location():
    resource_package = __name__
    path_root = pkg_resources.resource_filename(resource_package, "")
    ret = {
        "trustmark/ecguetesiegel":'/'.join((path_root,'trustmark/ecguetesiegel/')),
        "trustmark/ehi":'/'.join((path_root,'trustmark/ehi/')),
        "trustmark/europeantrustmark":'/'.join((path_root,'trustmark/europeantrustmark/')),
        "trustmark/trustedshops":'/'.join((path_root,'trustmark/trustedshops/')),
        "payment_provider/maestro":'/'.join((path_root,'payment_provider/maestro/')),
        "payment_provider/master":'/'.join((path_root,'payment_provider/master/')),
        "payment_provider/paypal":'/'.join((path_root,'payment_provider/paypal/')),
        "payment_provider/sofort_klarna":'/'.join((path_root,'payment_provider/sofort_klarna/')),
        "payment_provider/visa":'/'.join((path_root,'payment_provider/visa/'))
    }
    return ret





