# Logo Classifier

A Logo Classifier based on histogram similarity
Current parameterisation for detection of the e-commerge gütesiegel. 

    from logoclassifier import contains_logo_hybrid
    from logoclassifier import LogoClassifierECG

Test if any image that matches glob expression and 
file endings in LogoClassifierECG.image_endings matches the e-commerce-gütesiegel

    contains_logo_hybrid("certified_shops/www.viva-vinum.de/*")



List path of matches

    Classifier = LogoClassifierECG()
    Classifier.list_similar_images("certified_shops/www.weingrube.com/*")

Plot matches

    fig = Classifier.plot_cluster("certified_shops/www.weingrube.com/*")

Ajdust matching condition  or add new reference image

    Classifier.threshold =0.67
    Classifier.reference_hist = Classifier.calc_hist("train_ecg_large.png")
    Classifier.selector_metric  = 3
    Classifier.image_endings = [".jpg"]

    Classifier.contains_logo("certified_shops/www.weingrube.com/*")
